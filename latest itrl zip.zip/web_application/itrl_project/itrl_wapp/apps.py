from django.apps import AppConfig


class ItrlWappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'itrl_wapp'
